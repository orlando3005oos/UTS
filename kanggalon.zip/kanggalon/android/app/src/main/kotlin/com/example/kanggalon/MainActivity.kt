package com.example.kanggalon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
