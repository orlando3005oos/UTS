import 'package:flutter/material.dart';
import 'package:kanggalon/screens/login/loginScreens.dart';

final Map<String, WidgetBuilder> routes = {
  loginScreens.routeName: (context) => loginScreens()
};