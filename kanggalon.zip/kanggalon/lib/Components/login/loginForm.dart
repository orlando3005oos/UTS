import 'dart:html';

import 'package:flutter/material.dart';
import 'package:kanggalon/Components/costum_surfix_icons.dart';
import 'package:kanggalon/Components/default_button_custome_color.dart';
import 'package:kanggalon/size_config.dart';
import 'package:kanggalon/utils/constants.dart';


class SignInform extends StatefulWidget {
    @override
    _SignInForm createState() => _SignInForm();
}

class _SignInForm extends State<SignInform>{

  final _formKey = GlobalKey<FormState>();
  String? username;
  String? password;
  bool? remeber = false;

  TextEditingController txtUserName = TextEditingController(),
  txtPassword = TextEditingController();

  FocusNode focusNode = new FocusNode();

  @override
  Widget build(BuildContext context ) {
    return Form(
        child: Column(children: [
            buildUserName(),
            SizedBox(height: getProportionateScreenHeight(30)),
            buildPassword(),
            SizedBox(height: getProportionateScreenHeight(30)),
            Row(
              children: [
              Checkbox(value: remeber, onChanged: (value){
                setState(() {
                  remeber = value;
                });
              }),
              Text("Tetap Masuk"),
              Spacer(),
              GestureDetector(onTap: () {},
                child: Text("Lupa Password",
                style: TextStyle(decoration: TextDecoration.underline),
                ),
              )
            ],
          ),
          DefaultButtonCustomeColor(color: kPrimaryColor,
          text: "MASUK",
          press: () {},
          ),
          SizedBox(height: 20,
          ),
          GestureDetector( onTap: () {},
          child: Text(
            "Belum Punya Akun? Daftar di Sini",
            style: TextStyle(decoration: TextDecoration.underline),
          ),
          )
        ],
      ),
    );
  }

  TextFormField buildUserName() {
    return TextFormField(
      controller: txtUserName,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        labelText: 'Username',
        hintText: 'Masukan Nama Anda',
        labelStyle: TextStyle(color: focusNode.hasFocus ? mSubtitleColor : kPrimaryColor),
        floatingLabelBehavior: FloatingLabelBehavior.always,  
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/user.png",
        )
      ),
    );
  }

  TextFormField buildPassword() {
    return TextFormField(
      controller: txtPassword,
      obscureText: true,
      decoration: InputDecoration(
        labelText: 'Password',
        hintText: 'Masukan Password Anda',
        labelStyle: TextStyle(color: focusNode.hasFocus ? mSubtitleColor : kPrimaryColor),
        floatingLabelBehavior: FloatingLabelBehavior.always,  
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/pass.png",
        )
      ),
    );
  }
}