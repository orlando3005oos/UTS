import 'package:flutter/material.dart';
import 'package:kanggalon/routes.dart';
import 'package:kanggalon/screens/login/loginScreens.dart';
import 'package:kanggalon/theme.dart';

void main () async {
  runApp(
    MaterialApp(
      title: "Pesan Galon",
      theme: theme(),
      initialRoute: loginScreens.routeName,
      routes:routes,
    )
  );
}